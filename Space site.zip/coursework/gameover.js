function gameover() {
    const restart = document.getElementById('restart');
    const gameover = document.getElementById('gameover');


    restart.addEventListener('click', () => {
        location.reload();
    })
}